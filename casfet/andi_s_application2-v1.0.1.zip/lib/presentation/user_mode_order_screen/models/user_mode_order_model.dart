import 'package:get/get.dart';
import 'listrectanglesixtyseven_item_model.dart';

class UserModeOrderModel {
  RxList<ListrectanglesixtysevenItemModel> listrectanglesixtysevenItemList =
      RxList.filled(2, ListrectanglesixtysevenItemModel());
}
