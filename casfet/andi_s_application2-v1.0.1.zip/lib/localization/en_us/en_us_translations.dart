final Map<String, String> enUs = {
  'msg_network_err': 'Network Error',
  'msg_something_went_wrong': 'Something Went Wrong!',
  "msg_check_your_app_s":
      "Check your app's UI from the below demo screens of your app.",
  "msg_10_user_mode": "10. User Mode - Order",
  "lbl_total_fee": "Total Fee : ",
  "msg_rp_9_999_999_999": "Rp. 9,999,999,999",
  "lbl_remove": "Remove",
  "lbl_finalize_order": "Finalize Order",
  "lbl_app_navigation": "App Navigation",
  "msg_food_drink_name": "Food / Drink Name",
  "lbl_id_0000000000": "ID: 0000000000",
  "msg_you_ordered_quite": "you ordered quite a lot! hungry aren’t ya?",
  "lbl_price": "Price"
};
