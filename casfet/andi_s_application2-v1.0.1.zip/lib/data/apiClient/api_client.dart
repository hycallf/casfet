import 'package:andi_s_application2/core/app_export.dart';

class ApiClient extends GetConnect {}
