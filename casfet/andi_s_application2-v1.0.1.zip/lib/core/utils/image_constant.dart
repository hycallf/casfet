class ImageConstant {
  static String imgCft1 = 'assets/images/img_cft1.png';

  static String imgImage2 = 'assets/images/img_image2.png';

  static String imgImage9 = 'assets/images/img_image9.png';

  static String imageNotFound = 'assets/images/image_not_found.png';
}
